#ifndef NET_MINECRAFT_WORLD_ENTITY_MONSTER__Herobrine_H__
#define NET_MINECRAFT_WORLD_ENTITY_MONSTER__Herobrine_H__

// Herobrine: stands perfectly still, stares at the nearest player,
// and vanishes if you walk up to him, hit him, or wait long enough.
// (Header-only on purpose, so no build lists need to change.)

#include "Monster.h"
#include "../player/Player.h"
#include "../../level/Level.h"

class Herobrine: public Monster
{
	typedef Monster super;
public:
	// Not one of the built-in mob ids (10-13 animals, 32-36 monsters).
	static const int TYPE_ID = 37;

	// ---- Easy numbers to tweak ----
	// Game ticks are about 20 per second.
	static const int LIFETIME_TICKS   = 20 * 120;	// he disappears after 2 minutes
	static const int SEE_DISTANCE     = 64;			// he only exists while a player is this close (blocks)
	static const int VANISH_DISTANCE  = 4;			// he vanishes if you get this close (blocks)

	Herobrine(Level* level)
	:	super(level),
		lifeTicks(0)
	{
		textureName = "mob/herobrine.png";
		runSpeed = 0;
		attackDamage = 0;
	}

	virtual int getEntityTypeId() const { return TYPE_ID; }
	virtual int getMaxHealth() { return 20; }

	// No wandering, no attacking: just stand and stare.
	virtual void updateAi()
	{
		xxa = 0;
		yya = 0;
		jumping = false;
		noActionTime = 0;

		if (level->isClientSide) return;

		++lifeTicks;

		Player* player = level->getNearestPlayer(this, (float)SEE_DISTANCE);
		if (player == NULL || lifeTicks > LIFETIME_TICKS) {
			remove();
			return;
		}

		if (distanceTo(player) < (float)VANISH_DISTANCE) {
			remove();
			return;
		}

		lookAt(player, 30.0f, 30.0f);
	}

	// Hitting him makes him vanish instead of hurting him.
	virtual bool hurt(Entity* source, int dmg)
	{
		if (!level->isClientSide) remove();
		return false;
	}

	virtual bool removeWhenFarAway() { return false; }
	virtual int getDeathLoot() { return 0; }

protected:
	int lifeTicks;
};

#endif /*NET_MINECRAFT_WORLD_ENTITY_MONSTER__Herobrine_H__*/
