#ifndef NET_MINECRAFT_WORLD_ENTITY_MONSTER__FacelessSteve_H__
#define NET_MINECRAFT_WORLD_ENTITY_MONSTER__FacelessSteve_H__

// Faceless Steve  (based on the creepypasta)
//
//  * Looks like a normal Steve, but has no eyes. No name tag, no sounds.
//  * He does NOT attack right away. He studies the player for 2-3 in-game days:
//      - day 1: watches from far away, day 2: closer, day 3: very close
//        (if the player is inside a building he may appear right outside it).
//      - Some sightings he stands with his BACK to you, so he looks like a normal Steve.
//      - If you look at him he realises he was caught: he backs away and vanishes.
//      - Always at least ~7 blocks away while stalking.
//  * While watching, he learns what weapons you use (bow vs. sword/axe).
//  * When the study is over he attacks:
//      - If he saw you use a bow a lot, he EXPECTS arrows: he dodges them and
//        hops/hovers out of the way.
//      - If you never used ranged weapons, he does not expect them: the first arrow
//        shocks him (stunned a few seconds, takes extra damage), and he can't fly.
//      - If he gets hold of you (you die, or he stays on you), the world is "corrupted"
//        (see CORRUPT_RENAMES_WORLD below).
//  * If you kill him, he never comes back to that world.
//  * The seed "FACELESS STEVE" (all caps, with a space) attracts him quickly.
//
// Summoning:
//   * THE SHRINE: build it and he comes to fight you right now (skips the study).
//       bottom layer : a 3x3 square of OBSIDIAN
//       next layer   : an IRON ORE block in the middle (on the centre obsidian)
//                      and a TORCH on each of the 4 sides of it (north, south, east, west,
//                      NOT the corners). Placing the last piece summons him.
//   * Stalking block (TEST_SUMMON): place a GOLD BLOCK = start / summon a watcher right now.
//
// Header-only on purpose, so no build lists need to change.

#include <vector>
#include <string>
#include <cmath>

#include "Monster.h"
#include "../MobFactory.h"
#include "../EntityTypes.h"
#include "../player/Player.h"
#include "../../item/Item.h"
#include "../../item/ItemInstance.h"
#include "../../level/Level.h"
#include "../../level/storage/LevelData.h"
#include "../../level/tile/Tile.h"
#include "../../phys/Vec3.h"
#include "../../phys/HitResult.h"
#include "../../../util/Mth.h"
#include "../../../util/StringUtils.h"

// ---------------------------------------------------------------------------
// Easy numbers to tweak. Game ticks are 20 per second. One in-game day is
// Level::TICKS_PER_DAY ticks (16 real minutes).
// ---------------------------------------------------------------------------
namespace FacelessConfig {
	// --- the study period ---
	const float STALK_DAYS          = 2.5f;		// lore: 2-3 in-game days of watching
	const bool  FAST_TEST           = false;	// true = a "day" lasts only 3 real minutes (for testing)

	// --- how he shows up ---
	const int   RANDOM_START_CHANCE = 15000;	// 1 in N spawner calls (10 per second) = about 25 min on average
	const int   SEED_START_CHANCE   = 200;		// same, but on the FACELESS STEVE seed (about 20 s)
	const int   SIGHTING_MIN_TICKS  = 20 * 40;	// each sighting lasts 40 s ...
	const int   SIGHTING_MAX_TICKS  = 20 * 150;	// ... to 2.5 minutes
	const int   PAUSE_MIN_TICKS     = 20 * 30;	// pause between two sightings
	const int   PAUSE_MAX_TICKS     = 20 * 120;
	const float BACK_TO_YOU_CHANCE  = 0.5f;		// chance he stands with his back to you

	// distance from the player (min, max) for day 1 / day 2 / day 3 / attack
	const float DAY1_MIN = 38, DAY1_MAX = 56;
	const float DAY2_MIN = 22, DAY2_MAX = 36;
	const float DAY3_MIN = 11, DAY3_MAX = 20;
	const float INDOOR_MIN = 6, INDOOR_MAX = 12;	// day 2-3 and the player is inside a building
	const float ATTACK_MIN = 14, ATTACK_MAX = 22;

	// --- being caught ---
	const float LOOK_DOT            = 0.96f;	// how directly you must look at him (1.0 = dead centre)
	const int   NOTICE_TICKS        = 14;		// look at him this long and he knows he's been caught
	const int   RETREAT_TICKS       = 45;		// then he backs away for this long and vanishes
	const float TOO_CLOSE           = 7.0f;		// closer than this while stalking: he backs off

	// --- what he learns ---
	const int   LEARN_MIN_TICKS     = 300;		// he must have seen you use a bow this long (ticks) ...
	const int   RANGED_SHARE_PCT    = 20;		// ... and at least this % of your weapon time must be ranged

	// --- the fight ---
	const int   HEALTH              = 60;		// 30 hearts (a player has 10)
	const int   ATTACK_DAMAGE       = 5;		// 2.5 hearts
	const float CHASE_SPEED         = 0.85f;	// forward speed
	const int   DODGE_CHANCE_PCT    = 85;		// % of arrows he dodges if he expects them
	const int   STUN_TICKS          = 60;		// stunned 3 s by a surprise arrow
	const int   GRAB_TICKS          = 70;		// stays on you this long = he "gets hold" of you (works in creative)

	// --- what happens when he gets you ---
	const bool  CORRUPT_RENAMES_WORLD = true;	// rename the world to F_ACL_ES$ and turn it to night. Nothing is deleted.

	// --- testing ---
	const bool  TEST_SUMMON         = true;		// gold block = summon a watcher (the shrine always works)

	inline const char* corruptedName() { return "F_ACL_ES$"; }
	inline long dayTicks() { return FAST_TEST ? (long)(20 * 60 * 3) : (long)Level::TICKS_PER_DAY; }
	inline long stalkTicks() { return (long)((float)dayTicks() * STALK_DAYS); }
}

// ---------------------------------------------------------------------------
// What he remembers about this world (lives as long as the game is open)
// ---------------------------------------------------------------------------
enum FacelessPhase {
	FACELESS_NONE = 0,		// hasn't found this world yet
	FACELESS_STALKING,		// studying the player
	FACELESS_ATTACKING,		// study over: he attacks
	FACELESS_DEFEATED,		// killed: never returns
	FACELESS_TAKEN			// he got the player: the world is "corrupted"
};

struct FacelessState {
	Level* level;
	long seed;
	long lastTime;
	int phase;
	long stalkStart;
	long nextSighting;
	int rangedTicks, meleeTicks, otherTicks;	// what he saw the player hold
	FacelessState()
	:	level(NULL), seed(0), lastTime(0), phase(FACELESS_NONE), stalkStart(0), nextSighting(0),
		rangedTicks(0), meleeTicks(0), otherTicks(0) {}
};

inline std::vector<FacelessState>& facelessStates() {
	static std::vector<FacelessState> states;
	return states;
}

inline FacelessState& facelessState(Level* level) {
	std::vector<FacelessState>& v = facelessStates();
	long now = level->getTime();
	for (size_t i = 0; i < v.size(); ++i) {
		if (v[i].level != level) continue;
		// Same pointer but a different seed, or time jumped backwards: that's a different world.
		if (v[i].seed != level->getSeed() || now + 400 < v[i].lastTime) {
			v[i] = FacelessState();
			v[i].level = level;
			v[i].seed = level->getSeed();
		}
		v[i].lastTime = now;
		return v[i];
	}
	FacelessState s;
	s.level = level;
	s.seed = level->getSeed();
	s.lastTime = now;
	v.push_back(s);
	return v.back();
}

inline bool facelessSeedMatches(Level* level) {
	return level->getSeed() == (long)Util::hashCode(std::string("FACELESS STEVE"));
}

inline bool facelessExpectsRanged(const FacelessState& st) {
	if (st.rangedTicks < FacelessConfig::LEARN_MIN_TICKS) return false;
	int weapons = st.rangedTicks + st.meleeTicks;
	return st.rangedTicks * 100 >= weapons * FacelessConfig::RANGED_SHARE_PCT;
}

inline bool facelessIsMelee(Item* item) {
	if (item == NULL) return false;
	return item == Item::sword_wood || item == Item::sword_stone || item == Item::sword_iron
		|| item == Item::sword_gold || item == Item::sword_emerald
		|| item == Item::hatchet_wood || item == Item::hatchet_stone || item == Item::hatchet_iron
		|| item == Item::hatchet_gold || item == Item::hatchet_emerald;
}

// He got hold of the player: the "corruption".
inline void facelessTakePlayer(Level* level) {
	FacelessState& st = facelessState(level);
	if (st.phase == FACELESS_TAKEN) return;
	st.phase = FACELESS_TAKEN;
	if (FacelessConfig::CORRUPT_RENAMES_WORLD) {
		LevelData* data = level->getLevelData();
		if (data != NULL) data->setLevelName(FacelessConfig::corruptedName());
		long t = level->getTime();
		long base = (t / Level::TICKS_PER_DAY) * Level::TICKS_PER_DAY;
		level->setTime(base + Level::MIDDLE_OF_NIGHT_TIME);
	}
}

class FacelessSteve: public Monster
{
	typedef Monster super;
public:
	// Not one of the built-in mob ids (10-13 animals, 32-36 monsters).
	static const int TYPE_ID = 38;

	enum Mode { WATCH, RETREAT, ATTACK };

	FacelessSteve(Level* level)
	:	super(level),
		mode(WATCH), lifeTicks(0), maxLife(20 * 90),
		showBack(false), noticeTicks(0), retreatTicks(0),
		stunTicks(0), dodgeCooldown(0), flyTicks(0), grabTicks(0), taken(false)
	{
		textureName = "mob/faceless_steve.png";
		entityRendererId = ER_HUMANOID_RENDERER;
		runSpeed = 0;
		attackDamage = FacelessConfig::ATTACK_DAMAGE;
	}

	virtual int getEntityTypeId() const { return TYPE_ID; }
	virtual int getMaxHealth() { return FacelessConfig::HEALTH; }
	virtual bool removeWhenFarAway() { return false; }
	virtual int getDeathLoot() { return 0; }

	// Called right after creating him.
	void setup(bool attackNow, bool backToPlayer, int lifetime) {
		mode = attackNow ? ATTACK : WATCH;
		showBack = backToPlayer;
		maxLife = lifetime;
		if (attackNow) health = getMaxHealth();
	}

	virtual void updateAi()
	{
		xxa = 0;
		yya = 0;
		jumping = false;
		noActionTime = 0;

		if (level->isClientSide) return;

		++lifeTicks;
		FacelessState& st = facelessState(level);
		if (st.phase == FACELESS_DEFEATED || st.phase == FACELESS_TAKEN) { remove(); return; }

		Player* player = level->getNearestPlayer(this, 128.0f);
		if (player == NULL) { remove(); return; }

		float dist = distanceTo(player);
		bool los = hasLineOfSight(player);

		// Studying: he only learns while he can see you.
		if (dist < 72.0f && los) observe(player, st);

		// The study is over: from now on he attacks.
		if (mode == WATCH && st.phase == FACELESS_ATTACKING) mode = ATTACK;

		if (mode == WATCH) {
			watch(player, st, dist, los);
		} else if (mode == RETREAT) {
			retreat(player, dist);
		} else {
			attack(player, st, dist);
		}
	}

	// While he only watches, being hit scares him away. In the fight he is killable.
	virtual bool hurt(Entity* source, int dmg)
	{
		if (level->isClientSide) return super::hurt(source, dmg);

		if (mode != ATTACK) {
			if (mode == WATCH) beginRetreat();
			return false;
		}

		FacelessState& st = facelessState(level);
		bool arrow = (source != NULL && source->getEntityTypeId() == EntityTypes::IdArrow);
		if (arrow) {
			if (facelessExpectsRanged(st)) {
				// He saw you use a bow: he knows how to dodge.
				if (level->random.nextInt(100) < FacelessConfig::DODGE_CHANCE_PCT) {
					dodge();
					return false;
				}
			} else {
				// He did not expect arrows: shocked.
				if (stunTicks <= 0) stunTicks = FacelessConfig::STUN_TICKS;
				dmg += dmg / 2;
			}
		}
		return super::hurt(source, dmg);
	}

	virtual void die(Entity* source)
	{
		if (!level->isClientSide) {
			FacelessState& st = facelessState(level);
			if (st.phase != FACELESS_TAKEN) st.phase = FACELESS_DEFEATED;
		}
		super::die(source);
	}

protected:
	int mode;
	int lifeTicks, maxLife;
	bool showBack;
	int noticeTicks, retreatTicks;
	int stunTicks, dodgeCooldown, flyTicks, grabTicks;
	bool taken;

	bool hasLineOfSight(Player* player) {
		Vec3 a(player->x, player->y, player->z);
		Vec3 b(x, y + 1.6f, z);
		HitResult hr = level->clip(a, b);
		return hr.type == NO_HIT;
	}

	// What is the player holding?
	void observe(Player* player, FacelessState& st) {
		ItemInstance* it = player->getSelectedItem();
		Item* item = (it != NULL && it->count > 0) ? it->getItem() : NULL;
		if (item == NULL) { ++st.otherTicks; return; }
		if (item == Item::bow) ++st.rangedTicks;
		else if (facelessIsMelee(item)) ++st.meleeTicks;
		else ++st.otherTicks;
	}

	bool playerHoldsBow(Player* player) {
		ItemInstance* it = player->getSelectedItem();
		return it != NULL && it->count > 0 && it->getItem() == Item::bow;
	}

	// Is the player's crosshair on him?
	bool playerIsLookingAtMe(Player* player) {
		float yr = player->yRot * Mth::PI / 180.0f;
		float xr = player->xRot * Mth::PI / 180.0f;
		float lx = -Mth::sin(yr) * Mth::cos(xr);
		float ly = -Mth::sin(xr);
		float lz =  Mth::cos(yr) * Mth::cos(xr);

		float dx = x - player->x;
		float dy = (y + 1.4f) - player->y;
		float dz = z - player->z;
		float len = std::sqrt(dx * dx + dy * dy + dz * dz);
		if (len < 0.001f) return true;

		return (lx * dx + ly * dy + lz * dz) / len > FacelessConfig::LOOK_DOT;
	}

	void beginRetreat() {
		if (mode == RETREAT) return;
		mode = RETREAT;
		retreatTicks = 0;
	}

	// Stage 0/1/2 of the study, depending on how long it has been going on.
	int stage(FacelessState& st) {
		long total = FacelessConfig::stalkTicks();
		long done = level->getTime() - st.stalkStart;
		if (done * 100 < total * 34) return 0;
		if (done * 100 < total * 72) return 1;
		return 2;
	}

	void watch(Player* player, FacelessState& st, float dist, bool los) {
		if (lifeTicks > maxLife) { remove(); return; }

		// Too close: he backs off.
		if (dist < FacelessConfig::TOO_CLOSE) { beginRetreat(); return; }

		// Caught?
		if (los && playerIsLookingAtMe(player)) {
			if (++noticeTicks >= FacelessConfig::NOTICE_TICKS) { beginRetreat(); return; }
		} else if (noticeTicks > 0) {
			--noticeTicks;
		}

		// He stares at you ... unless he is standing with his back to you.
		if (!showBack) lookAt(player, 30.0f, 30.0f);
	}

	void retreat(Player* player, float dist) {
		// He realised he was caught: face you, walk backwards, then he is gone.
		lookAt(player, 40.0f, 40.0f);
		yya = -0.45f;
		if (horizontalCollision && onGround) jumping = true;
		if (++retreatTicks > FacelessConfig::RETREAT_TICKS || dist > 90.0f) remove();
	}

	void dodge() {
		Player* player = level->getNearestPlayer(this, 128.0f);
		if (player == NULL) return;
		float dx = player->x - x;
		float dz = player->z - z;
		float len = std::sqrt(dx * dx + dz * dz);
		if (len < 0.01f) return;
		float side = (level->random.nextInt(2) == 0) ? 1.0f : -1.0f;
		xd += (-dz / len) * 0.5f * side;
		zd += ( dx / len) * 0.5f * side;
		if (onGround) yd = 0.42f;
	}

	void attack(Player* player, FacelessState& st, float dist) {
		if (st.phase == FACELESS_STALKING) st.phase = FACELESS_ATTACKING;

		// He got you.
		if (!player->isAlive() || player->health <= 0) {
			facelessTakePlayer(level);
			remove();
			return;
		}

		if (dodgeCooldown > 0) --dodgeCooldown;

		// Stunned by a surprise arrow: he just stands there.
		if (stunTicks > 0) {
			--stunTicks;
			lookAt(player, 30.0f, 30.0f);
			return;
		}

		// He expects arrows: hop out of the way, and even hover while you aim.
		bool expects = facelessExpectsRanged(st);
		if (expects && playerHoldsBow(player) && dist > 5.0f && playerIsLookingAtMe(player)) {
			if (dodgeCooldown <= 0 && level->random.nextInt(12) == 0) {
				dodge();
				dodgeCooldown = 14;
			}
			if (flyTicks <= 0 && level->random.nextInt(40) == 0) flyTicks = 30;
		}
		if (flyTicks > 0) {
			--flyTicks;
			if (yd < 0.17f) yd = 0.17f;
			fallDistance = 0;
		}

		// Stay on you for too long and he has you (this also works in creative).
		if (dist < 2.6f) {
			if (++grabTicks >= FacelessConfig::GRAB_TICKS) {
				facelessTakePlayer(level);
				remove();
				return;
			}
		} else if (grabTicks > 0) {
			--grabTicks;
		}

		if (dist <= 15.0f) {
			// Normal zombie-style chasing and hitting.
			runSpeed = FacelessConfig::CHASE_SPEED;
			setAttackTarget(player);
			super::updateAi();
		} else {
			// Far away: just run straight at you.
			lookAt(player, 30.0f, 30.0f);
			yya = FacelessConfig::CHASE_SPEED;
			if (horizontalCollision && onGround) jumping = true;
		}
	}
};

// ---------------------------------------------------------------------------
// Where and when he shows up
// ---------------------------------------------------------------------------
namespace FacelessSpawn {

	// Find a standing spot (min..max blocks from the player) that the player could see.
	inline bool findSpot(Level* level, Player* p, float minD, float maxD, bool needSight,
	                     float& sx, float& sy, float& sz) {
		for (int attempt = 0; attempt < 48; ++attempt) {
			float angle = level->random.nextFloat() * 2.0f * Mth::PI;
			float dist = minD + level->random.nextFloat() * (maxD - minD);
			int x = Mth::floor(p->x + Mth::cos(angle) * dist);
			int z = Mth::floor(p->z + Mth::sin(angle) * dist);
			if (x < 1 || x >= 255 || z < 1 || z >= 255) continue;

			int top = Mth::floor(p->y) + 12;
			int bottom = Mth::floor(p->y) - 14;
			if (bottom < 2) bottom = 2;
			if (top > 120) top = 120;

			for (int yy = top; yy >= bottom; --yy) {
				bool ok = level->isSolidBlockingTile(x, yy - 1, z)
					&& !level->isSolidBlockingTile(x, yy, z)
					&& !level->isSolidBlockingTile(x, yy + 1, z)
					&& !level->getMaterial(x, yy, z)->isLiquid();
				if (!ok) continue;

				if (needSight) {
					Vec3 a(p->x, p->y, p->z);
					Vec3 b((float)x + 0.5f, (float)yy + 1.6f, (float)z + 0.5f);
					HitResult hr = level->clip(a, b);
					if (hr.type != NO_HIT) continue;
				}
				sx = (float)x + 0.5f; sy = (float)yy; sz = (float)z + 0.5f;
				return true;
			}
		}
		return false;
	}

	inline bool spawn(Level* level, Player* p, float minD, float maxD, bool needSight, bool attackNow) {
		float sx, sy, sz;
		if (!findSpot(level, p, minD, maxD, needSight, sx, sy, sz)) return false;

		bool back = !attackNow && level->random.nextFloat() < FacelessConfig::BACK_TO_YOU_CHANCE;
		float toPlayer = std::atan2(p->z - sz, p->x - sx) * 180.0f / Mth::PI - 90.0f;
		float yaw = back ? toPlayer + 180.0f : toPlayer;

		FacelessSteve* f = new FacelessSteve(level);
		f->moveTo(sx, sy, sz, yaw, 0);
		f->yBodyRot = f->yBodyRotO = yaw;
		int life = FacelessConfig::SIGHTING_MIN_TICKS
			+ level->random.nextInt(FacelessConfig::SIGHTING_MAX_TICKS - FacelessConfig::SIGHTING_MIN_TICKS);
		f->setup(attackNow, back, life);
		if (!level->addEntity(f)) { delete f; return false; }
		return true;
	}

	inline void scheduleNext(Level* level, FacelessState& st) {
		int pause = FacelessConfig::PAUSE_MIN_TICKS
			+ level->random.nextInt(FacelessConfig::PAUSE_MAX_TICKS - FacelessConfig::PAUSE_MIN_TICKS);
		if (FacelessConfig::FAST_TEST) pause /= 4;
		st.nextSighting = level->getTime() + pause;
	}

	inline void begin(Level* level, FacelessState& st) {
		st.phase = FACELESS_STALKING;
		st.stalkStart = level->getTime();
		st.nextSighting = level->getTime() + 20 * 20;	// first sighting after about 20 seconds
	}

	// Called from the mob spawner (10 times per second).
	inline void tick(Level* level) {
		if (level->isClientSide || level->players.empty()) return;
		FacelessState& st = facelessState(level);
		if (st.phase == FACELESS_DEFEATED || st.phase == FACELESS_TAKEN) return;

		Player* p = level->players[0];
		long now = level->getTime();

		if (st.phase == FACELESS_NONE) {
			int chance = facelessSeedMatches(level) ? FacelessConfig::SEED_START_CHANCE
			                                        : FacelessConfig::RANDOM_START_CHANCE;
			if (level->random.nextInt(chance) == 0) begin(level, st);
			return;
		}

		if (st.phase == FACELESS_STALKING && now - st.stalkStart >= FacelessConfig::stalkTicks()) {
			st.phase = FACELESS_ATTACKING;
			st.nextSighting = now;
		}

		if (level->countInstanceOfType(FacelessSteve::TYPE_ID) > 0) return;
		if (now < st.nextSighting) return;

		if (st.phase == FACELESS_ATTACKING) {
			if (spawn(level, p, FacelessConfig::ATTACK_MIN, FacelessConfig::ATTACK_MAX, false, true))
				st.nextSighting = now + 20 * 20;
			else
				st.nextSighting = now + 20 * 3;
			return;
		}

		// Still studying: pick the distance for this stage.
		long total = FacelessConfig::stalkTicks();
		long done = now - st.stalkStart;
		float minD, maxD;
		bool needSight = true;
		if (done * 100 < total * 34) { minD = FacelessConfig::DAY1_MIN; maxD = FacelessConfig::DAY1_MAX; }
		else if (done * 100 < total * 72) { minD = FacelessConfig::DAY2_MIN; maxD = FacelessConfig::DAY2_MAX; }
		else { minD = FacelessConfig::DAY3_MIN; maxD = FacelessConfig::DAY3_MAX; }

		// Past day 1 and you're indoors: he shows up right outside, where you can see him.
		int px = Mth::floor(p->x), py = Mth::floor(p->y), pz = Mth::floor(p->z);
		bool indoors = !level->canSeeSky(px, py, pz);
		if (done * 100 >= total * 34 && indoors && level->random.nextInt(2) == 0) {
			minD = FacelessConfig::INDOOR_MIN; maxD = FacelessConfig::INDOOR_MAX;
		}

		if (spawn(level, p, minD, maxD, needSight, false)) scheduleNext(level, st);
		else st.nextSighting = now + 20 * 10;	// no good spot: try again in 10 seconds
	}

	// Is there a finished shrine whose iron ore block is at (cx, cy, cz)?
	//   layer below the ore : 3x3 of obsidian (the ore sits on the middle one)
	//   same layer as the ore: a torch on each of the 4 sides (not the corners)
	inline bool isShrine(Level* level, int cx, int cy, int cz) {
		if (Tile::ironOre == NULL || Tile::obsidian == NULL || Tile::torch == NULL) return false;
		if (level->getTile(cx, cy, cz) != Tile::ironOre->id) return false;
		for (int dx = -1; dx <= 1; ++dx)
			for (int dz = -1; dz <= 1; ++dz)
				if (level->getTile(cx + dx, cy - 1, cz + dz) != Tile::obsidian->id) return false;
		int torch = Tile::torch->id;
		return level->getTile(cx + 1, cy, cz) == torch && level->getTile(cx - 1, cy, cz) == torch
			&& level->getTile(cx, cy, cz + 1) == torch && level->getTile(cx, cy, cz - 1) == torch;
	}

	// Did the block just placed at (x, y, z) finish a shrine?
	inline bool completesShrine(Level* level, int x, int y, int z) {
		int t = level->getTile(x, y, z);
		if (Tile::ironOre != NULL && t == Tile::ironOre->id) return isShrine(level, x, y, z);
		if (Tile::torch != NULL && t == Tile::torch->id) {
			return isShrine(level, x + 1, y, z) || isShrine(level, x - 1, y, z)
				|| isShrine(level, x, y, z + 1) || isShrine(level, x, y, z - 1);
		}
		if (Tile::obsidian != NULL && t == Tile::obsidian->id) {
			for (int dx = -1; dx <= 1; ++dx)
				for (int dz = -1; dz <= 1; ++dz)
					if (isShrine(level, x + dx, y + 1, z + dz)) return true;
		}
		return false;
	}

	// Called after the player places a block.
	inline void onBlockPlaced(Level* level, int x, int y, int z) {
		if (level->isClientSide || level->players.empty()) return;
		FacelessState& st = facelessState(level);
		if (st.phase == FACELESS_DEFEATED || st.phase == FACELESS_TAKEN) return;
		Player* p = level->players[0];

		// The shrine: skip the study, he comes to fight now.
		if (completesShrine(level, x, y, z)) {
			if (st.phase == FACELESS_NONE) begin(level, st);
			st.stalkStart = level->getTime() - FacelessConfig::stalkTicks() - 1;
			st.phase = FACELESS_ATTACKING;
			if (level->countInstanceOfType(FacelessSteve::TYPE_ID) == 0)
				spawn(level, p, FacelessConfig::ATTACK_MIN, FacelessConfig::ATTACK_MAX, false, true);
			return;
		}

		// Test block: a gold block starts the study (if needed) and shows him right now.
		if (!FacelessConfig::TEST_SUMMON) return;
		if (Tile::goldBlock == NULL || level->getTile(x, y, z) != Tile::goldBlock->id) return;
		if (st.phase == FACELESS_NONE) begin(level, st);
		if (st.phase == FACELESS_STALKING && level->countInstanceOfType(FacelessSteve::TYPE_ID) == 0) {
			float minD = FacelessConfig::DAY1_MIN, maxD = FacelessConfig::DAY1_MAX;
			if (!spawn(level, p, minD, maxD, true, false)) spawn(level, p, 15.0f, 30.0f, false, false);
			scheduleNext(level, st);
		}
	}
}

#endif /*NET_MINECRAFT_WORLD_ENTITY_MONSTER__FacelessSteve_H__*/
