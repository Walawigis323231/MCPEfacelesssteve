#ifndef NET_MINECRAFT_WORLD_ENTITY_MONSTER__Herobrine_H__
#define NET_MINECRAFT_WORLD_ENTITY_MONSTER__Herobrine_H__

// Herobrine
//  * Randomly: a quiet stalker. Appears far away, stands still and stares, with
//              NO explosion, night or mobs. He vanishes if you look at him,
//              if you walk within 4 blocks, or after 2 minutes.
//  * Shrine:   build a 3x3 layer of bricks with a gold block in the middle.
//              The moment Herobrine appears on the gold block there is a huge
//              explosion sound, it turns night and 15 creepers, 15 zombies and
//              15 skeletons spawn around it. He stays 30 seconds, then vanishes
//              and fire is lit on the gold block.
//  * TEST SWITCH (on in this build): a single gold block summons a quiet stalker
//     about 10 blocks to your right. Set TEST_SUMMON = false to turn it off, so
//     that only the full shrine summons him.
//  * Touch the shrine Herobrine and he hits you for 2 hearts (once a second).
//  * While he is around he plays scary break / place / footstep sounds.
// (Header-only on purpose, so no build lists need to change.)

#include <vector>
#include <cmath>

#include "Monster.h"
#include "../MobFactory.h"
#include "../player/Player.h"
#include "../../level/Level.h"
#include "../../level/tile/Tile.h"
#include "../../level/tile/FireTile.h"

// ---------------------------------------------------------------------------
// Easy numbers to tweak. Game ticks are about 20 per second.
// ---------------------------------------------------------------------------
namespace HerobrineConfig {
	const int RANDOM_LIFETIME_TICKS = 20 * 120;	// random Herobrine stays 2 minutes
	const int SHRINE_LIFETIME_TICKS = 20 * 30;	// shrine Herobrine stays 30 seconds
	const int SEE_DISTANCE          = 64;		// random Herobrine needs a player this close (blocks)
	const int VANISH_DISTANCE       = 4;		// random Herobrine vanishes if you get this close
	const float LOOK_DOT            = 0.94f;	// how directly you must look at him (1.0 = dead centre)
	const int LOOK_GRACE_TICKS      = 40;		// can't be "looked away" in his first 2 seconds
	const int LOOK_VANISH_TICKS     = 10;		// look at him this long (0.5 s) and he vanishes

	const int MOBS_PER_TYPE         = 15;		// creepers, zombies and skeletons each
	const int FIRE_STAYS_CALLS      = 3000;		// shrine fire is kept lit about 5 minutes
	const int SOUND_CHANCE          = 120;		// scare sound roughly every 6 seconds (higher = rarer)

	const float TOUCH_DISTANCE      = 1.5f;		// closer than this counts as touching him
	const int TOUCH_DAMAGE          = 4;		// 4 = 2 hearts (1 heart = 2)
	const int TOUCH_COOLDOWN_TICKS  = 20;		// one hit per second while touching

	const float EXPLOSION_VOLUME    = 10.0f;	// how loud the appearance explosion is
	const bool  TEST_SUMMON         = true;		// TESTING: a single gold block summons a quiet stalker
	const float TEST_SUMMON_DIST    = 10.0f;	// how far in front of you he appears
	const bool  RANDOM_HAS_EVENT    = false;	// false = random stalker is quiet: no explosion, night or mobs
}

// ---------------------------------------------------------------------------
// Shrine helpers
// ---------------------------------------------------------------------------
struct HerobrineShrineFire {
	Level* level;
	int x, y, z;
	int callsLeft;
};

inline std::vector<HerobrineShrineFire>& herobrineShrineFires() {
	static std::vector<HerobrineShrineFire> fires;
	return fires;
}

// Called from the mob spawner every couple of ticks. Fire on a gold block would
// burn out by itself after a few seconds, so this keeps it lit for a while.
inline void herobrineKeepFiresBurning(Level* level) {
	std::vector<HerobrineShrineFire>& fires = herobrineShrineFires();
	for (size_t i = 0; i < fires.size(); ) {
		HerobrineShrineFire& f = fires[i];
		if (f.level != level || --f.callsLeft <= 0) {
			fires.erase(fires.begin() + i);
			continue;
		}
		if (level->getTile(f.x, f.y, f.z) == 0 && level->getTile(f.x, f.y - 1, f.z) != 0) {
			level->setTile(f.x, f.y, f.z, Tile::fire->id);
		}
		++i;
	}
}

inline void herobrineSpawnShrineMobs(Level* level, int cx, int cz) {
	const int types[3] = { MobTypes::Creeper, MobTypes::Zombie, MobTypes::Skeleton };
	for (int t = 0; t < 3; ++t) {
		int placed = 0;
		for (int attempt = 0; attempt < 200 && placed < HerobrineConfig::MOBS_PER_TYPE; ++attempt) {
			float angle = level->random.nextFloat() * 2.0f * Mth::PI;
			float dist = 4.0f + level->random.nextFloat() * 10.0f;
			int x = Mth::floor((float)cx + 0.5f + Mth::cos(angle) * dist);
			int z = Mth::floor((float)cz + 0.5f + Mth::sin(angle) * dist);
			if (x < 0 || x >= 256 || z < 0 || z >= 256) continue;

			int y = level->getTopSolidBlock(x, z);
			bool ok = level->isSolidBlockingTile(x, y - 1, z)
				&& !level->isSolidBlockingTile(x, y, z)
				&& !level->isSolidBlockingTile(x, y + 1, z)
				&& !level->getMaterial(x, y, z)->isLiquid();
			if (!ok) continue;

			Mob* mob = MobFactory::CreateMob(types[t], level);
			if (!mob) break;
			mob->moveTo((float)x + 0.5f, (float)y, (float)z + 0.5f, level->random.nextFloat() * 360, 0);
			if (level->addEntity(mob)) ++placed;
			else delete mob;
		}
	}
}

// Everything that happens the moment Herobrine appears: huge explosion sound,
// turns night, and the mobs spawn right away (around hx, hz).
inline void herobrineAppearEvent(Level* level, Player* player, float hx, float hy, float hz) {
	// Huge explosion: layered at different pitches, heard at the player and at Herobrine.
	const float pitches[3] = { 0.5f, 0.7f, 0.9f };
	for (int i = 0; i < 3; ++i) {
		if (player != NULL)
			level->playSound(player->x, player->y, player->z, "random.explode", HerobrineConfig::EXPLOSION_VOLUME, pitches[i]);
		level->playSound(hx, hy, hz, "random.explode", HerobrineConfig::EXPLOSION_VOLUME, pitches[i]);
	}

	// Night time
	long t = level->getTime();
	long base = (t / Level::TICKS_PER_DAY) * Level::TICKS_PER_DAY;
	level->setTime(base + Level::MIDDLE_OF_NIGHT_TIME);

	// Mobs appear together with him
	herobrineSpawnShrineMobs(level, Mth::floor(hx), Mth::floor(hz));
}

// Defined after the Herobrine class.
inline void herobrineShrineFinish(Level* level, int cx, int cy, int cz);

class Herobrine: public Monster
{
	typedef Monster super;
public:
	// Not one of the built-in mob ids (10-13 animals, 32-36 monsters).
	static const int TYPE_ID = 37;

	bool shrineMode;

	Herobrine(Level* level)
	:	super(level),
		shrineMode(false),
		lifeTicks(0),
		shrineX(0), shrineY(0), shrineZ(0),
		burstLeft(0), burstKind(0), burstTimer(0),
		burstX(0), burstY(0), burstZ(0), burstDX(0), burstDZ(0),
		touchCooldown(0), lookTicks(0)
	{
		textureName = "mob/herobrine.png";
		runSpeed = 0;
		attackDamage = 0;
	}

	void setShrine(int cx, int cy, int cz) {
		shrineMode = true;
		shrineX = cx; shrineY = cy; shrineZ = cz;
	}

	virtual int getEntityTypeId() const { return TYPE_ID; }
	virtual int getMaxHealth() { return 20; }

	// No wandering, no attacking: just stand and stare.
	virtual void updateAi()
	{
		xxa = 0;
		yya = 0;
		jumping = false;
		noActionTime = 0;

		if (level->isClientSide) return;

		++lifeTicks;

		if (shrineMode) {
			if (lifeTicks > HerobrineConfig::SHRINE_LIFETIME_TICKS) {
				herobrineShrineFinish(level, shrineX, shrineY, shrineZ);
				remove();
				return;
			}
			Player* player = level->getNearestPlayer(this, -1);
			if (player != NULL) lookAt(player, 30.0f, 30.0f);
			touchHit(player);
			scareSounds(player);
			return;
		}

		Player* player = level->getNearestPlayer(this, (float)HerobrineConfig::SEE_DISTANCE);
		if (player == NULL || lifeTicks > HerobrineConfig::RANDOM_LIFETIME_TICKS) {
			remove();
			return;
		}

		// Walk toward him and he's gone.
		if (distanceTo(player) < (float)HerobrineConfig::VANISH_DISTANCE) {
			remove();
			return;
		}

		// Look at him and he's gone.
		if (lifeTicks > HerobrineConfig::LOOK_GRACE_TICKS && playerIsLookingAtMe(player)) {
			if (++lookTicks >= HerobrineConfig::LOOK_VANISH_TICKS) {
				remove();
				return;
			}
		} else {
			lookTicks = 0;
		}

		lookAt(player, 30.0f, 30.0f);
		scareSounds(player);
	}

	// Hitting the random Herobrine makes him vanish. The shrine one ignores hits.
	virtual bool hurt(Entity* source, int dmg)
	{
		if (!shrineMode && !level->isClientSide) remove();
		return false;
	}

	virtual bool removeWhenFarAway() { return false; }
	virtual int getDeathLoot() { return 0; }

protected:
	int lifeTicks;
	int shrineX, shrineY, shrineZ;

	// scare sound state
	int burstLeft, burstKind, burstTimer;
	float burstX, burstY, burstZ, burstDX, burstDZ;

	// touching Herobrine hurts
	int touchCooldown;

	// how long the player has been looking straight at him
	int lookTicks;

	bool playerIsLookingAtMe(Player* player) {
		float yr = player->yRot * Mth::PI / 180.0f;
		float xr = player->xRot * Mth::PI / 180.0f;
		float lx = -Mth::sin(yr) * Mth::cos(xr);
		float ly = -Mth::sin(xr);
		float lz =  Mth::cos(yr) * Mth::cos(xr);

		float dx = x - player->x;
		float dy = y - player->y;
		float dz = z - player->z;
		float len = std::sqrt(dx * dx + dy * dy + dz * dz);
		if (len < 0.001f) return true;

		return (lx * dx + ly * dy + lz * dz) / len > HerobrineConfig::LOOK_DOT;
	}

	void touchHit(Player* player) {
		if (touchCooldown > 0) --touchCooldown;
		if (player == NULL || touchCooldown > 0) return;
		if (distanceTo(player) < HerobrineConfig::TOUCH_DISTANCE) {
			player->hurt(this, HerobrineConfig::TOUCH_DAMAGE);
			touchCooldown = HerobrineConfig::TOUCH_COOLDOWN_TICKS;
		}
	}

	// Sound for the block at the burst position: kind 0 = break, 1 = place, 2 = footstep
	void playBurstSound() {
		int bx = Mth::floor(burstX);
		int bz = Mth::floor(burstZ);
		int gy = level->getTopSolidBlock(bx, bz) - 1;
		int t = level->getTile(bx, gy, bz);
		std::string name = "step.grass";
		float vol = 1.0f, pitch = 1.0f;
		if (t > 0 && Tile::tiles[t] != NULL && Tile::tiles[t]->soundType != NULL && Tile::tiles[t]->soundType->getVolume() > 0) {
			const Tile::SoundType* st = Tile::tiles[t]->soundType;
			vol = st->getVolume();
			pitch = st->getPitch();
			name = (burstKind == 0) ? st->getBreakSound() : st->getStepSound();
		}
		if (burstKind == 0) { vol = (vol + 1) / 2; pitch *= 0.8f; }		// like breaking a block
		else if (burstKind == 1) { vol = (vol + 1) / 2; pitch *= 0.8f; }	// like placing a block
		else { vol *= 0.75f; pitch *= 0.95f + level->random.nextFloat() * 0.1f; }	// footstep
		level->playSound(burstX, (float)gy + 1.0f, burstZ, name, vol, pitch);
	}

	void scareSounds(Player* player) {
		if (player == NULL) return;

		if (burstLeft > 0) {
			if (--burstTimer <= 0) {
				playBurstSound();
				--burstLeft;
				if (burstKind == 2) { burstX += burstDX; burstZ += burstDZ; burstTimer = 9 + level->random.nextInt(3); }
				else burstTimer = 6 + level->random.nextInt(8);
			}
			return;
		}

		if (level->random.nextInt(HerobrineConfig::SOUND_CHANCE) != 0) return;

		float angle = level->random.nextFloat() * 2.0f * Mth::PI;
		float dist = 4.0f + level->random.nextFloat() * 6.0f;
		burstX = player->x + Mth::cos(angle) * dist;
		burstZ = player->z + Mth::sin(angle) * dist;
		if (burstX < 1 || burstX > 254 || burstZ < 1 || burstZ > 254) return;
		burstY = player->y;

		burstKind = level->random.nextInt(3);
		burstTimer = 1;
		if (burstKind == 0) burstLeft = 1 + level->random.nextInt(3);			// break
		else if (burstKind == 1) burstLeft = 1 + level->random.nextInt(2);		// place
		else {																	// footsteps creeping closer
			burstLeft = 4 + level->random.nextInt(5);
			burstDX = (player->x - burstX) / dist * 0.8f;
			burstDZ = (player->z - burstZ) / dist * 0.8f;
		}
	}
};

inline void herobrineShrineFinish(Level* level, int cx, int cy, int cz) {
	// Fire on top of the gold block, kept lit for a while.
	level->setTile(cx, cy + 1, cz, Tile::fire->id);
	HerobrineShrineFire f;
	f.level = level; f.x = cx; f.y = cy + 1; f.z = cz;
	f.callsLeft = HerobrineConfig::FIRE_STAYS_CALLS;
	herobrineShrineFires().push_back(f);
	// (The mobs already spawned when he appeared.)
}

// ---------------------------------------------------------------------------
// Shrine detection: called after the player places a block.
// ---------------------------------------------------------------------------
namespace HerobrineShrine {

	inline bool isBrick(int t) {
		if (t <= 0) return false;
		if (Tile::redBrick && t == Tile::redBrick->id) return true;
		if (Tile::stoneBrickSmooth && t == Tile::stoneBrickSmooth->id) return true;
		return false;
	}

	inline bool isComplete(Level* level, int cx, int cy, int cz) {
		if (level->getTile(cx, cy, cz) != Tile::goldBlock->id) return false;
		for (int dx = -1; dx <= 1; ++dx)
			for (int dz = -1; dz <= 1; ++dz) {
				if (dx == 0 && dz == 0) continue;
				if (!isBrick(level->getTile(cx + dx, cy, cz + dz))) return false;
			}
		// room for Herobrine on top
		return level->getTile(cx, cy + 1, cz) == 0 && level->getTile(cx, cy + 2, cz) == 0;
	}

	inline void activate(Level* level, int cx, int cy, int cz) {
		// Already a shrine Herobrine around? Do nothing. A random one? Send him away.
		for (size_t i = 0; i < level->entities.size(); ++i) {
			Entity* e = level->entities[i];
			if (e->getEntityTypeId() == Herobrine::TYPE_ID && !e->removed) {
				Herobrine* h = (Herobrine*)e;
				if (h->shrineMode) return;
				h->remove();
			}
		}

		// Herobrine on top of the gold block
		Herobrine* h = new Herobrine(level);
		h->setShrine(cx, cy, cz);
		Player* p = level->players.empty() ? NULL : level->players[0];
		float yaw = level->random.nextFloat() * 360;
		h->moveTo((float)cx + 0.5f, (float)cy + 1.0f, (float)cz + 0.5f, yaw, 0);
		if (p != NULL) h->lookAt(p, 360.0f, 360.0f);
		if (!level->addEntity(h)) { delete h; return; }

		// Explosion, night and mobs, all at the moment he appears.
		herobrineAppearEvent(level, p, (float)cx + 0.5f, (float)cy + 1.0f, (float)cz + 0.5f);
	}

	// TEST MODE: summon a staring Herobrine in front of the player, with the full event.
	inline void summonTest(Level* level) {
		Player* p = level->players.empty() ? NULL : level->players[0];
		if (p == NULL) return;

		// Only one Herobrine at a time.
		for (size_t i = 0; i < level->entities.size(); ++i) {
			Entity* e = level->entities[i];
			if (e->getEntityTypeId() == Herobrine::TYPE_ID && !e->removed) return;
		}

		// Start straight ahead of the player, then try other directions if that spot is bad.
		float base = p->yRot * Mth::PI / 180.0f - Mth::PI / 2.0f;	// to the player's side, not straight ahead
		for (int i = 0; i < 12; ++i) {
			float a = base + (float)i * (Mth::PI / 6.0f);
			int x = Mth::floor(p->x - Mth::sin(a) * HerobrineConfig::TEST_SUMMON_DIST);
			int z = Mth::floor(p->z + Mth::cos(a) * HerobrineConfig::TEST_SUMMON_DIST);
			if (x < 0 || x >= 256 || z < 0 || z >= 256) continue;

			int y = level->getTopSolidBlock(x, z);
			bool ok = level->isSolidBlockingTile(x, y - 1, z)
				&& !level->isSolidBlockingTile(x, y, z)
				&& !level->isSolidBlockingTile(x, y + 1, z)
				&& !level->getMaterial(x, y, z)->isLiquid();
			if (!ok) continue;

			Herobrine* h = new Herobrine(level);
			h->moveTo((float)x + 0.5f, (float)y, (float)z + 0.5f, 0, 0);
			h->lookAt(p, 360.0f, 360.0f);
			if (!level->addEntity(h)) { delete h; return; }
			if (HerobrineConfig::RANDOM_HAS_EVENT)
				herobrineAppearEvent(level, p, (float)x + 0.5f, (float)y, (float)z + 0.5f);
			return;
		}
	}

	inline void onBlockPlaced(Level* level, int x, int y, int z) {
		if (level->isClientSide) return;
		int t = level->getTile(x, y, z);
		if (t != Tile::goldBlock->id && !isBrick(t)) return;
		for (int cx = x - 1; cx <= x + 1; ++cx)
			for (int cz = z - 1; cz <= z + 1; ++cz)
				if (isComplete(level, cx, y, cz)) {
					activate(level, cx, y, cz);
					return;
				}

		if (HerobrineConfig::TEST_SUMMON && t == Tile::goldBlock->id)
			summonTest(level);
	}
}

#endif /*NET_MINECRAFT_WORLD_ENTITY_MONSTER__Herobrine_H__*/
